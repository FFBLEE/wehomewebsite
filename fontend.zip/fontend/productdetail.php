<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/detail.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
    integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA=="
    crossorigin="anonymous" />
  <link href="https://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/tiny-slider.css" rel="stylesheet">
  <title>WEHOME</title>
  <link rel="shortcut icon" href="upload/wehomelogo.ico">
</head>

<body>

  <!-- Navbar -->
  <nav class="custom-navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">
    <div class="container">
      <a class="navbar-brand" href="index.php">WEHOME<span>.</span></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni"
        aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsFurni">
        <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">หน้าหลัก</a>
          </li>
          <li><a class="nav-link" href="product.php">สินค้า</a></li>
          <li><a class="nav-link" href="about.php">เกี่ยวกับเรา</a></li>
          <li><a class="nav-link" href="contact.php">ติดต่อ</a></li>
        </ul>

        <ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
          <li><a class="nav-link" href="login.php"><img src="css/user.svg"></a></li> <!-- เชื่อมกับ Loginpage -->
        </ul>

      </div>
    </div>
  </nav>

  <!-- productdetail -->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" />
  <div class="container">

    <div class="product-content product-wrap clearfix product-deatil">
      <div class="row">
        <div class="col-md-5 col-sm-12 col-xs-12">
          <div class="product-image">
            <div id="myCarousel-2" class="carousel slide">
              <ol class="carousel-indicators">
                <li data-target="#myCarousel-2" data-slide-to="0" class></li>
                <li data-target="#myCarousel-2" data-slide-to="1" class="active"></li>
                <li data-target="#myCarousel-2" data-slide-to="2" class></li>
              </ol>
              <div class="carousel-inner">

                <div class="item active">
                  <img src="https://www.bootdey.com/image/700x400/FFB6C1/000000" class="img-responsive" alt />
                </div>

                <div class="item">
                  <img src="https://www.bootdey.com/image/700x400/87CEFA/000000" class="img-responsive" alt />
                </div>

                <div class="item">
                  <img src="https://www.bootdey.com/image/700x400/B0C4DE/000000" class="img-responsive" alt />
                </div>
              </div>
              <a class="left carousel-control" href="#myCarousel-2" data-slide="prev"> <span
                  class="glyphicon glyphicon-chevron-left"></span> </a>
              <a class="right carousel-control" href="#myCarousel-2" data-slide="next"> <span
                  class="glyphicon glyphicon-chevron-right"></span> </a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-md-offset-1 col-sm-12 col-xs-12">
          <h2 class="name">IPHONE 14
            <small>Product by <a href="javascript:void(0);">WEHOME</a></small>
            <!-- <i class="fa fa-star fa-2x text-primary"></i>
<i class="fa fa-star fa-2x text-primary"></i>
<i class="fa fa-star fa-2x text-primary"></i>
<i class="fa fa-star fa-2x text-primary"></i>
<i class="fa fa-star fa-2x text-muted"></i> -->
            <!-- <span class="fa fa-2x"><h5>(109) Votes</h5></span>
<a href="javascript:void(0);">109 customer reviews</a> -->
          </h2>
          <hr />
          <!-- <h3 class="price-container">
$129.54
<small>*includes tax</small>
</h3>
<div class="certified">
<ul>
<li>
<a href="javascript:void(0);">Delivery time<span>7 Working Days</span></a>
</li>
<li>
<a href="javascript:void(0);">Certified<span>Quality Assured</span></a>
</li>
</ul>
</div>
<hr/> -->
          <div class="description description-tabs">
            <ul id="myTab" class="nav nav-pills">
              <li class="active"><a href="#more-information" data-toggle="tab" class="no-margin">Product Description
                </a></li>
              <li class><a href="#specifications" data-toggle="tab">Specifications</a></li>
              <!-- <li class><a href="#reviews" data-toggle="tab">Reviews</a></li> -->
            </ul>
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade active in" id="more-information">
                <br />
                <strong>Description Title</strong>
                <p>
                  ระบบกล้องระดับโปร กล้องหลัก 48MP อัลตร้าไวด์
                  เทเลโฟโต้
                  ภาพถ่ายความละเอียดสูงเป็นพิเศษ (24MP และ 48MP)
                  ภาพถ่ายบุคคลเจเนอเรชั่นถัดไป
                </p>
              </div>
              <div class="tab-pane fade" id="specifications">
                <br />
                <dl class>
                  <dt>COPYRIGHT@PONKITTI</dt>
                  <dd>RMUTSV KITTIPOM</dd>
                  <br />
                  <dt>COPYRIGHT@PATIPHAN</dt>
                  <dd>RMUTSV PATIPHAN</dd>
                  <br />
                  <dt>COPYRIGHT@SUDARAT</dt>
                  <dd>RMUTSV SUDARAT</dd>
                </dl>
              </div>
              <div class="tab-pane fade" id="reviews">
                <br />
                <!-- <form method="post" class="well padding-bottom-10" onsubmit="return false;">
<textarea rows="2" class="form-control" placeholder="Write a review"></textarea>
<div class="margin-top-10">
<button type="submit" class="btn btn-sm btn-primary pull-right">
Submit Review
</button>
<a href="javascript:void(0);" class="btn btn-link profile-link-btn" rel="tooltip" data-placement="bottom" title data-original-title="Add Location"><i class="fa fa-location-arrow"></i></a>
<a href="javascript:void(0);" class="btn btn-link profile-link-btn" rel="tooltip" data-placement="bottom" title data-original-title="Add Voice"><i class="fa fa-microphone"></i></a>
<a href="javascript:void(0);" class="btn btn-link profile-link-btn" rel="tooltip" data-placement="bottom" title data-original-title="Add Photo"><i class="fa fa-camera"></i></a>
<a href="javascript:void(0);" class="btn btn-link profile-link-btn" rel="tooltip" data-placement="bottom" title data-original-title="Add File"><i class="fa fa-file"></i></a>
</div>
</form> -->

              </div>
            </div>

          </div>
          <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
          <script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
          <script type="text/javascript"></script>
</body>