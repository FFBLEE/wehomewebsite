<!DOCTYPE html>
<html lang="en">

<!DOCTYPE html>
<html lang="en">

<?php include('include/header.php') ?>

<body>

  <!-- productdetail -->
  <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <div class="container">

    <div class="product-content product-wrap clearfix product-deatil">
      <div class="row">
        <div class="col-md-5 col-sm-12 col-xs-12">
          <div class="product-image">
            <div id="myCarousel-2" class="carousel slide">
              <ol class="carousel-indicators">
                <li data-target="#myCarousel-2" data-slide-to="0" class></li>
                <li data-target="#myCarousel-2" data-slide-to="1" class="active"></li>
                <li data-target="#myCarousel-2" data-slide-to="2" class></li>
              </ol>
              <div class="carousel-inner">

                <div class="item active">
                  <img src="https://www.bootdey.com/image/700x400/FFB6C1/000000" class="img-responsive" alt />
                </div>

                <div class="item">
                  <img src="https://www.bootdey.com/image/700x400/87CEFA/000000" class="img-responsive" alt />
                </div>

                <div class="item">
                  <img src="https://www.bootdey.com/image/700x400/B0C4DE/000000" class="img-responsive" alt />
                </div>
              </div>
              <a class="left carousel-control" href="#myCarousel-2" data-slide="prev"> <span
                  class="glyphicon glyphicon-chevron-left"></span> </a>
              <a class="right carousel-control" href="#myCarousel-2" data-slide="next"> <span
                  class="glyphicon glyphicon-chevron-right"></span> </a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-md-offset-1 col-sm-12 col-xs-12">
          <h2 class="name">IPHONE 14
            <small>Product by <a href="javascript:void(0);">WEHOME</a></small>
          </h2>
          <hr />
          <div class="description description-tabs">
            <ul id="myTab" class="nav nav-pills">
              <li class="active"><a href="#more-information" data-toggle="tab" class="no-margin">รายละเอียดสินค้า</a>
              </li>
              <li class><a href="#specifications" data-toggle="tab">ใบรับรองสินค้า</a></li>
            </ul>
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade active in" id="more-information">
                <br />
                <strong>Description Title</strong>
                <p>
                  ระบบกล้องระดับโปร กล้องหลัก 48MP อัลตร้าไวด์
                  เทเลโฟโต้
                  ภาพถ่ายความละเอียดสูงเป็นพิเศษ (24MP และ 48MP)
                  ภาพถ่ายบุคคลเจเนอเรชั่นถัดไป
                </p>
              </div>
              <div class="tab-pane fade" id="specifications">
                <br />
                <dl class>
                  <dt>COPYRIGHT@PONKITTI</dt>
                  <dd>RMUTSV KITTIPOM</dd>
                  <br />
                  <dt>COPYRIGHT@PATIPHAN</dt>
                  <dd>RMUTSV PATIPHAN</dd>
                  <br />
                  <dt>COPYRIGHT@SUDARAT</dt>
                  <dd>RMUTSV SUDARAT</dd>
                </dl>
              </div>
              <div class="tab-pane fade" id="reviews">
                <br />

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
  <script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script type="text/javascript">$(document).ready(function () {
      $('#myCarousel-2').carousel();
    });
  </script>



</body>
<?php include('include/footer.php') ?>

</html>