<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/product.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <title>WEHOME</title>
    <link rel="shortcut icon" href="upload/wehomelogo.ico"> 
  </head>
<body>

     <!-- Navbar -->
<nav class="custom-navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">
      <div class="container">
        <a class="navbar-brand" href="index.php">WEHOME<span>.</span></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsFurni">
          <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">หน้าหลัก</a>
            </li>
            <li><a class="nav-link" href="product.php">สินค้า</a></li>
            <li><a class="nav-link" href="about.html">เกี่ยวกับเรา</a></li>
            <li><a class="nav-link" href="contact.html">ติดต่อ</a></li>
          </ul>
          
          <ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
						<li><a class="nav-link" href="login.php"><img src="css/user.svg"></a></li> <!-- เชื่อมกับ Loginpage -->
					</ul>

        </div>
      </div>
    </nav>


 
   
<div class="container bootdey">
  <div class="col-md-3">
    <section class="panel">
      <div class="panel-body">
  <input type="text" placeholder="Keyword Search" class="form-control" />
</div>
    </section>
  <section class="panel">
<header class="panel-heading">Category</header>
  <div class="panel-body">
    <ul class="nav prod-cat">
        <li><a href="#" class="active"><i class="fa fa-angle-right"></i> Dress</a>
    <ul class="nav">
        <li class="active"><a href="#">- Shirt</a></li>
    <li><a href="#">- Pant</a></li>
      <li><a href="#">- Shoes</a></li>
    </ul>
</li>
<li><a href="#"><i class="fa fa-angle-right"></i> Bags &amp; Purses</a>
  </li>
    <li><a href="#"><i class="fa fa-angle-right"></i> Beauty</a>
</li>
  <li><a href="#"><i class="fa fa-angle-right"></i> Coat &amp; Jacket</a>
</li>
    <li><a href="#"><i class="fa fa-angle-right"></i> Jeans</a>
</li>
  <li><a href="#"><i class="fa fa-angle-right"></i> Jewellery</a>
</li>
    <li><a href="#"><i class="fa fa-angle-right"></i> Electronics</a>
</li>
  <li><a href="#"><i class="fa fa-angle-right"></i> Sports</a>
</li>
    <li><a href="#"><i class="fa fa-angle-right"></i> Technology</a>
</li>
  <li><a href="#"><i class="fa fa-angle-right"></i> Watches</a>
</li>
    <li><a href="#"><i class="fa fa-angle-right"></i> Accessories</a>
</li>
    </ul>
  </div>
      </section>
<section class="panel">
<div class="panel-body sliders">
    <div id="slider-range" class="slider">
      </div>
  <div class="slider-info">
  <span id="slider-range-amount"></span>
    </div>
  </div>
  </section>
<section class="panel">
<header class="panel-heading">Filter</header>
  <div class="panel-body">
    <form role="form product-form">
      <div class="form-group">
        <label>Brand</label>
<select class="form-control hasCustomSelect" style="-webkit-appearance: menulist-button; width: 231px; position: absolute; opacity: 0; height: 34px; font-size: 12px;">
<option>Wallmart</option>
<option>Catseye</option>
<option>Moonsoon</option>
<option>Textmart</option>
</select>
<span class="customSelect form-control" style="display: inline-block;"><span class="customSelectInner" style="width: 209px; display: inline-block;">Wallmart</span></span>
</div>
<div class="form-group">
<label>Color</label>
<select class="form-control hasCustomSelect" style="-webkit-appearance: menulist-button; width: 231px; position: absolute; opacity: 0; height: 34px; font-size: 12px;">
<option>White</option>
<option>Black</option>
<option>Red</option>
<option>Green</option>
</select>
<span class="customSelect form-control" style="display: inline-block;"><span class="customSelectInner" style="width: 209px; display: inline-block;">White</span></span>
</div>
<div class="form-group">
<label>Type</label>
<select class="form-control hasCustomSelect" style="-webkit-appearance: menulist-button; width: 231px; position: absolute; opacity: 0; height: 34px; font-size: 12px;">
<option>Small</option>
<option>Medium</option>
<option>Large</option>
<option>Extra Large</option>
</select>
<span class="customSelect form-control" style="display: inline-block;"><span class="customSelectInner" style="width: 209px; display: inline-block;">Small</span></span>
</div>
<button class="btn btn-primary" type="submit">Filter</button>
</form>
</div>
</section>
<section class="panel">
<header class="panel-heading">
Best Seller
</header>
<div class="panel-body">
<div class="best-seller">
<article class="media">
<a class="pull-left thumb p-thumb">
<img src="https://www.bootdey.com/image/250x220/FFB6C1/000000" />
</a>
<div class="media-body">
<a href="#" class="p-head">Item One Tittle</a>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
</div>
</article>
<article class="media">
<a class="pull-left thumb p-thumb">
<img src="https://www.bootdey.com/image/250x220/A2BE2/000000" />
</a>
<div class="media-body">
<a href="#" class="p-head">Item Two Tittle</a>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
</div>
</article>
<article class="media">
<a class="pull-left thumb p-thumb">
<img src="https://www.bootdey.com/image/250x220/6495ED/000000" />
</a>
<div class="media-body">
<a href="#" class="p-head">Item Three Tittle</a>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
</div>
</article>
</div>
</div>
</section>
</div>
<div class="col-md-9">
<section class="panel">
<div class="panel-body">
<div class="pull-right">
<ul class="pagination pagination-sm pro-page-list">
<li><a href="#">1</a></li>
<li><a href="#">2</a></li>
<li><a href="#">3</a></li>
<li><a href="#">»</a></li>
</ul>
</div>
</div>
</section>
<div class="row product-list">
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/FFB6C1/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/6495ED/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/FF7F50/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/00BFFF/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/00CED1/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/9400D3/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/FFD700/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/ADD8E6/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/20B2AA/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/3CB371/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/FFB6C1/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/C71585/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/191970/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/87CEEB/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
<div class="col-md-4">
<section class="panel">
<div class="pro-img-box">
<img src="https://www.bootdey.com/image/250x220/FFB6C1/000000" alt />
<a href="#" class="adtocart">
<i class="fa fa-shopping-cart"></i>
</a>
</div>
<div class="panel-body text-center">
<h4>
<a href="#" class="pro-title">
Leopard Shirt Dress
</a>
</h4>
</div>
</section>
</div>
</div>
</div>
</div>

<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript"></script>
  </body>
</html>