<!DOCTYPE html>
<html lang="en">

<?php include('include/header.php') ?>

<body>

  <!-- product body    -->
  <div class="container bootdey">
    <div class="row"> <!-- Added row div here -->
      <!-- Left Sidebar -->
      <div class="col-md-3">
        <section class="panel">
          <header class="panel-heading">Category</header>
          <div class="panel-body">
            <ul class="nav prod-cat">
              <li><a href="#" class="active"><i class="fa fa-angle-right"></i> Dress</a>
                <ul class="nav">
                  <li class="active"><a href="#">- Shirt</a></li>
                  <li><a href="#">- Pant</a></li>
                  <li><a href="#">- Shoes</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </section>

        <!-- left side product -->
        <section class="panel">
          <header class="panel-heading">สินค้าแนะนำ</header>
          <div class="panel-body">
            <div class="best-seller">
              <article class="media">
                <a class="pull-left thumb p-thumb">
                  <img src="https://www.bootdey.com/image/250x220/FFB6C1/000000" />
                </a>
                <div class="media-body">
                  <a href="productdetail.php" class="p-head">IPHONE 23</a>
                  <p>ระบบกล้องระดับโปร กล้องหลัก 48MP อัลตร้าไวด์ เทเลโฟโต้ ภาพถ่ายความละเอียดสูงเป็นพิเศษ (24MP และ
                    48MP) ภาพถ่ายบุคคลเจเนอเรชั่นถัดไป</p>
                </div>
        </section>
      </div>

      <!-- product_card -->
      <div class="col-md-5">
        <section class="panel">
          <div class="row product-list">
            <div class="col-md-5">
              <section class="panel">
                <div class="pro-img-box">
                  <img src="https://www.bootdey.com/image/250x220/FFB6C1/000000" alt />
                  </a>
                </div>
                <div class="panel-body text-center">
                  <h4><a href="productdetail.php" class="pro-title">- IPHONE 13 -</a></h4>
                  <p>ระบบกล้องระดับโปร กล้องหลัก 48MP อัลตร้าไวด์ เทเลโฟโต้ ภาพถ่ายความละเอียดสูงเป็นพิเศษ</p>
                </div>
              </section>
            </div>
          </div> <!-- End of row div -->
      </div>
    </div>
  </div>
  </div>





  
  <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
  <script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript"></script>
</body>

<?php include('include/footer.php') ?>

</html>