<!DOCTYPE html>
<html lang="en">

<?php include('include/header.php')?>	
<link rel="stylesheet" href="css/product.css">

<body>

  <!-- product body    -->
  <div class="container bootdey">
    <div class="col-md-3">
      <section class="panel">
        <div class="panel-body">
          <input type="text" placeholder="Keyword Search" class="form-control" />
        </div>
      </section>
      <section class="panel">
        <header class="panel-heading">Category</header>
        <div class="panel-body">
          <ul class="nav prod-cat">
            <li><a href="#" class="active"><i class="fa fa-angle-right"></i> Dress</a>
              <ul class="nav">
                <li class="active"><a href="#">- Shirt</a></li>
                <li><a href="#">- Pant</a></li>
                <li><a href="#">- Shoes</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </section>
      <section class="panel">
        <div class="panel-body sliders">
          <div id="slider-range" class="slider">
          </div>
          <div class="slider-info">
            <span id="slider-range-amount"></span>
          </div>
        </div>
      </section>
      <!-- <section class="panel">
<header class="panel-heading">Filter</header>
  <div class="panel-body">
    <form role="form product-form">
      <div class="form-group">
        <label>Brand</label>
<select class="form-control hasCustomSelect" style="-webkit-appearance: menulist-button; width: 231px; position: absolute; opacity: 0; height: 34px; font-size: 12px;">
<option>Wallmart</option>
<option>Catseye</option>
<option>Moonsoon</option>
<option>Textmart</option>
</select>
<span class="customSelect form-control" style="display: inline-block;"><span class="customSelectInner" style="width: 209px; display: inline-block;">Wallmart</span></span>
</div>
<div class="form-group">
<label>Color</label>
<select class="form-control hasCustomSelect" style="-webkit-appearance: menulist-button; width: 231px; position: absolute; opacity: 0; height: 34px; font-size: 12px;">
<option>White</option>
<option>Black</option>
<option>Red</option>
<option>Green</option>
</select>
<span class="customSelect form-control" style="display: inline-block;"><span class="customSelectInner" style="width: 209px; display: inline-block;">White</span></span>
</div>
<div class="form-group">
<label>Type</label>
<select class="form-control hasCustomSelect" style="-webkit-appearance: menulist-button; width: 231px; position: absolute; opacity: 0; height: 34px; font-size: 12px;">
<option>Small</option>
<option>Medium</option>
<option>Large</option>
<option>Extra Large</option>
</select>
<span class="customSelect form-control" style="display: inline-block;"><span class="customSelectInner" style="width: 209px; display: inline-block;">Small</span></span>
</div>
<button class="btn btn-primary" type="submit">Filter</button>
</form>
</div>
</section> -->

      <!-- left side product -->

      <section class="panel">
        <header class="panel-heading">สินค้าแนะนำ</header>
        <div class="panel-body">
          <div class="best-seller">
            <article class="media">
              <a class="pull-left thumb p-thumb">
                <img src="https://www.bootdey.com/image/250x220/FFB6C1/000000" />
              </a>
              <div class="media-body">
                <a href="productdetail.php" class="p-head">IPHONE 23</a>
                <p>ระบบกล้องระดับโปร กล้องหลัก 48MP อัลตร้าไวด์ เทเลโฟโต้ ภาพถ่ายความละเอียดสูงเป็นพิเศษ (24MP และ 48MP) ภาพถ่ายบุคคลเจเนอเรชั่นถัดไป</p>
              </div>
            </article>
          </div>
        </div>
      </section>
    </div>

    <!-- page selection -->
    <div class="col-md-9">
      <section class="panel">
        <div class="panel-body">
          <div class="pull-right">
            <ul class="pagination pagination-sm pro-page-list">
              <li><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">»</a></li>
            </ul>
          </div>
        </div>
      </section>

      <!-- product_card -->

      <div class="row product-list">
        <div class="col-md-4">
          <section class="panel">
            <div class="pro-img-box">
              <img src="https://www.bootdey.com/image/250x220/FFB6C1/000000" alt />
              <!-- <a href="#" class="adtocart">
                <i class="fa fa-shopping-cart"></i> -->
              </a>
            </div>
            <div class="panel-body text-center">
              <h4><a href="productdetail.php" class="pro-title">- IPHONE 13 -</a></h4>
              <p>ระบบกล้องระดับโปร กล้องหลัก 48MP อัลตร้าไวด์ เทเลโฟโต้ ภาพถ่ายความละเอียดสูงเป็นพิเศษ</p>
            </div>
          </section>
        </div>
      </div>
    </div>
  </div>
  </div>

  <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
  <script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript"></script>
</body>

</html>