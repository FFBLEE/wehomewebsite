<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link href="css/tiny-slider.css" rel="stylesheet">
    <title>WEHOME</title>
    <link rel="shortcut icon" href="upload/wehomelogo.ico"> 
  </head>
  <body>
  
    <!-- Navbar -->
    <nav class="custom-navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">
      <div class="container">
        <a class="navbar-brand" href="index.php">WEHOME<span>.</span></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsFurni">
          <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">หน้าหลัก</a>
            </li>
            <li><a class="nav-link" href="product.php">สินค้า</a></li>
            <li><a class="nav-link" href="about.html">เกี่ยวกับเรา</a></li>
            <li><a class="nav-link" href="contact.html">ติดต่อ</a></li>
          </ul>
          
          <ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
						<li><a class="nav-link" href="login.php"><img src="css/user.svg"></a></li> <!-- เชื่อมกับ Loginpage -->
					</ul>

        </div>
      </div>
    </nav>

    <!-- Carousel -->
    <div id="carouselExampleIndicators" class="carousel slide">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="upload/p1.png" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="upload/p2.jpeg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="upload/p4.jpg" class="d-block w-100" alt="...">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>

    <!-- product -->
    
   <!-- Start Product Section -->
		<div class="product-section">
			<div class="container">
				<div class="row">

        <!-- Start Column 1 -->
					<div class="col-md-12 col-lg-3 mb-5 mb-lg-0">
						<h2 class="mb-4 section-title">Product Preview</h2>
						<p class="mb-4">Product Detail Or Text</p>
						<p><a href="product.php" class="btn">Explore</a></p>
					</div> 
					<!-- End Column 1 -->

          <!-- Start Column 2 -->
					<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
						<a class="product-item" href="productdetail.php">
							<img src="upload/product-1.png" class="img-fluid product-thumbnail">
							<h3 class="product-title">Nordic Chair</h3>
							<!-- <strong class="product-price">$50.00</strong> -->

							<!-- <span class="icon-cross">
								<img src="" class="img-fluid">
							</span> -->
						</a>
					</div> 
					<!-- End Column 2 -->
          <!-- Start Column 3 -->
					<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
						<a class="product-item" href="productdetail.php">
							<img src="upload/product-2.png" class="img-fluid product-thumbnail">
							<h3 class="product-title">Kruzo Aero Chair</h3>
							<!-- <strong class="product-price">$78.00</strong> -->

							<!-- <span class="icon-cross">
								<img src="" class="img-fluid">
							</span> -->
						</a>
					</div>
					<!-- End Column 3 -->

					<!-- Start Column 4 -->
					<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
						<a class="product-item" href="productdetail.php">
							<img src="upload/product-3.png" class="img-fluid product-thumbnail">
							<h3 class="product-title">Ergonomic Chair</h3>
							<!-- <strong class="product-price">$43.00</strong> -->
							
              <!-- <span class="icon-cross">
								<img src="" class="img-fluid">
							</span> -->
						</a>
					</div>
					<!-- End Column 4 -->

				</div>
			</div>
		</div>
		<!-- End Product Section -->

    <!-- Start Why Choose Us Section -->
	
    <div class="why-choose-section">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-12"> <!-- changed the column size to 12 for full width -->
                <h2 class="section-title">วีโฮมเซอร์วิส</h2>
                <p></p>

                <div class="row">
                    <div class="col-4 col-md-4"> <!-- changed column size to 4 to fit 3 columns in a row -->
                        <div class="feature">
                            <div class="icon">
                                <img src="css/truck.svg" alt="Image" class="imf-fluid">
                            </div>
                            <h3>ติดตามการสั่งซื้อสินค้าทั่วประเทศ</h3>
                            <p>บริการจัดส่งสินค้าถึงที่ ที่ลูกค้าต้องการ</p>
                        </div>
                    </div>

                    <div class="col-4 col-md-4"> <!-- changed column size to 4 to fit 3 columns in a row -->
                        <div class="feature">
                            <div class="icon">
                                <img src="css/bag.svg" alt="Image" class="imf-fluid">
                            </div>
                            <h3>รับประกันการคืนสินค้า</h3>
                            <p>สภาพสมบูรณ์ 100% ภายใน 30 วัน</p>
                        </div>
                    </div>

                    <div class="col-4 col-md-4"> <!-- changed column size to 4 to fit 3 columns in a row -->
                        <div class="feature">
                            <div class="icon">
                                <img src="css/support.svg" alt="Image" class="imf-fluid">
                            </div>
                            <h3>Contact Center</h3>
                            <p>000-000000 (จ.ส. 08.00-17.00 น.)</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
	<!-- End Why Choose Us Section -->



    <script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
